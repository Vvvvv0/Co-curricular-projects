class Settings:
    """存储游戏的设置类。"""
    
    def __init__(self):
        """初始化游戏的设置。"""
        self.screen_width = 800  # 屏幕宽度
        self.screen_height = 600  # 屏幕高度
        self.bg_color = (135, 206, 235)# 背景颜色，RGB值
        self.ship_speed = 0.5  # 飞船速度

        # 子弹设置
        self.bullet_speed = 0.5  # 子弹速度
        self.bullet_width = 3
        self.bullet_height = 15
        self.bullet_color = (60, 60, 60)
        self.bullets_allowed = 3

        # 外星人设置
        self.alien_speed = 0.5  # 外星人速度
        self.fleet_drop_speed = 0.5 # 外星人下移速度
        self.fleet_direction = 1  # 外星人移动方向，1表示向右，-1表示向左

        self.ship_limit = 3

        self.speedup_scale = 1.1
        self.score_scale = 1.5

        self.initalize_dynamic_settings()

    def initalize_dynamic_settings(self):
        self.ship_speed = 1.5 
        self.bullet_speed = 3.0 
        self.alien_speed = 1.0
        self.fleet_direction = 1
        self.alien_points = 50

    def increase_speed(self):
        self.ship_speed *= self.speedup_scale
        self.bullet_speed *= self.speedup_scale
        self.alien_speed *= self.speedup_scale

        self.alien_points = int(self.alien_points * self.score_scale)