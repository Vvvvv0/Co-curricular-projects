import pygame
import sys

from time import sleep
from settings import Settings
from ship import Ship
from alien import Alien
from bullet import Bullet
from game_stats import GameStats
from button import Button
from scoreboard import Scoreboard

class AlienInvasion:
    """管理游戏资源和行为的类。"""
    def __init__(self):
        """初始化游戏并创建游戏资源。"""
        pygame.init()
        self.settings = Settings()
        # 初始化屏幕
        self.screen = pygame.display.set_mode((self.settings.screen_width, self.settings.screen_height))
        self.screen_rect_width = self.screen.get_rect().width  # 获取屏幕宽度
        self.screen_rect_height = self.screen.get_rect().height
        pygame.display.set_caption("Alien Invasion") # 設置窗口標題

        """设置背景颜色。"""
        self.bg_color = (self.settings.bg_color) # RGB颜色值, (230, 230, 230) 是浅灰色

        self.ship = Ship(self) # 创建飞船实例
        self.stats = GameStats(self)
        self.sb = Scoreboard(self)
        self.bullets = pygame.sprite.Group()
        self.aliens = pygame.sprite.Group()

        self._create_fleet()  # 创建外星人舰队
        self.play_button = Button(self, "Play")

    def run_game(self):
        """开始游戏的主循环。"""
        while True:
            self._check_events() # 检查事件
            self._update_screen()  # 更新屏幕
            if self.stats.game_active:
                self.ship.update()
                self._update_aliens()
                self._update_bullets()  # 更新子弹位置
                self._update_screen()  # 更新屏幕
        
    def _check_events(self):
        """响应按键和鼠标事件。"""
        for event in pygame.event.get(): # 按下按鈕, 移動鍵都是Event
                if event.type == pygame.QUIT: # 如果點擊關閉遊戲視窗
                    sys.exit()
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    mouse_pos = pygame.mouse.get_pos()
                    self._check_play_button(mouse_pos)
                elif event.type == pygame.KEYDOWN:
                    self._check_keydown_events(event)
                elif event.type == pygame.KEYUP:
                    self._check_keyup_events(event)

    def _check_play_button(self, mouse_pos):
        button_clicked = self.play_button.rect.collidepoint(mouse_pos)
        if button_clicked and not self.stats.game_active:
            pygame.mouse.set_visible(False)
            self.stats.reset_stats()
            self.stats.game_active = True
            self.sb.prep_score()
            self.sb.prep_level()
            self.sb.prep_ships()

            self.aliens.empty()
            self.bullets.empty()

            self._create_fleet()
            self.ship.center_ship()
            self.settings.initalize_dynamic_settings()

    def _check_keydown_events(self, event):
            if event.key == pygame.K_RIGHT:
                 # 右移
                self.ship.moving_right = True
            elif event.key == pygame.K_LEFT:
                self.ship.moving_left = True
            elif event.key == pygame.K_ESCAPE or event.key == pygame.K_q:
                sys.exit()
            elif event.key == pygame.K_SPACE:
                self._fire_bullet()

    def _check_keyup_events(self, event):
            if event.key == pygame.K_RIGHT:
                self.ship.moving_right = False # 停止右移
            elif event.key == pygame.K_LEFT:
                self.ship.moving_left = False # 停止左移

    def _fire_bullet(self):
        """创建一个子弹并将其添加到编组bullets中。"""
        if len(self.bullets) < self.settings.bullets_allowed: # 最多允许同時發射3个子弹
            new_bullet = Bullet(self)
            self.bullets.add(new_bullet)

    def _update_bullets(self):
        """更新子弹的位置并删除已消失的子弹。"""
        self.bullets.update()
        for bullet in self.bullets.copy():
                if bullet.rect.bottom <= 0:
                    self.bullets.remove(bullet)
        self._check_bullet_alien_collisions()   # 检查子弹与外星人之间的碰撞

    def _check_bullet_alien_collisions(self):
        """检查子弹与外星人之间的碰撞，并处理碰撞。"""
        collisions = pygame.sprite.groupcollide(self.bullets, self.aliens, True, True)
        if collisions:
            for aliens in collisions.values():
                self.stats.score += self.settings.alien_points * len(aliens)
            self.sb.prep_score()
            self.sb.check_high_score()
        if not self.aliens:
            self.bullets.empty()
            self._create_fleet()
            self.settings.increase_speed()

            self.stats.level += 1
            self.sb.prep_level()
        
    def _create_fleet(self):
        alien = Alien(self) # 创建一个外星人本體
        alien_width, alien_height = alien.rect.size # 获取外星人的宽度和高度
        available_space_x = self.screen_rect_width - (2 * alien_width)
        number_aliens_x = available_space_x // (2 * alien_width)
        ship_height = self.ship.rect.height
        available_space_y = (self.screen_rect_height - (3 * alien_height) - ship_height)
        number_rows = available_space_y // (2 * alien_height)

        for row_number in range(number_rows):
            # 创建一行外星人
            for alien_number in range(number_aliens_x):
                self._create_aliens(alien_number, row_number)

    def _create_aliens(self, alien_number, row_number):
        # 创建第一隻外星人
            alien = Alien(self)
            alien_width, alien_height = alien.rect.size # 获取外星人的宽度和高度
            alien.x = alien_width + 2 * alien_width * alien_number # alien.x = 我定的位置, alien.rect.x = 畫的位置
            alien.rect.x = alien.x
            alien.rect.y = alien.rect.height + 2 * alien.rect.height * row_number
            self.aliens.add(alien)

    def _update_aliens(self):
        self._check_fleet_edges()
        self.aliens.update()
        # 检查是否有外星人到达屏幕边缘
        
        if pygame.sprite.spritecollideany(self.ship, self.aliens):
            self._ship_hit()
        self._check_aliens_bottom()

    def _ship_hit(self):
        if self.stats.ships_left > 0:
            self.stats.ships_left -= 1
            self.sb.prep_ships()
            # .empty()  (Python) list有野就false, 無野就true (Pygame) 在 Pygame 的 Sprite.Group 中，.empty() 是一個方法，會直接移除群組內的所有精靈（sprite），而不是僅僅返回 True 或 False。
            self.aliens.empty()
            self.bullets.empty()
            self._create_fleet()
            self.ship.center_ship()
            sleep(0.5) # 讓玩家可以看見外星人撞上太空船, 而不是馬上跳轉
        else:
            self.stats.game_active = False
            pygame.mouse.set_visible(True)

    def _check_aliens_bottom(self):
        screen_rect = self.screen.get_rect()
        for alien in self.aliens.sprites():
                # 有一個碰到底就呼叫_ship_hit(), 後跳出迴圈
            if alien.rect.bottom >= screen_rect.bottom:
                self._ship_hit()
                break
        
    def _check_fleet_edges(self):
        """检查外星人是否到达屏幕边缘，并改变方向。"""
        for alien in self.aliens.sprites():
            if alien.check_edges():
                self._change_fleet_direction()
                break

    def _change_fleet_direction(self):
        """改变外星人舰队的方向。"""
        for alien in self.aliens.sprites():
            alien.rect.y += self.settings.fleet_drop_speed
        self.settings.fleet_direction *= -1

    def _update_screen(self):
        self.screen.fill(self.bg_color) # 填充背景色
        self.ship.blitme()
        self.aliens.draw(self.screen)
        self.sb.show_score()
        if not self.stats.game_active:
            self.play_button.draw_button()
        for bullet in self.bullets.sprites():
            bullet.draw_bullet()

        pygame.display.flip() # 更新屏幕, 把最近繪製的內容顯示出來 #放最後
        
if __name__ == '__main__':
    """创建一个游戏实例并运行游戏。"""
    ai = AlienInvasion()
    ai.run_game()