import sys
import time
import random
import heapq
import matplotlib.pyplot as plt
from PIL import Image
from pynput import keyboard
from threading import Thread, Event
from queue import Queue, Empty

DATABASE = {
    'Q1': {
        'question': "Which dynasty began the construction of the Great Wall of China?",
        'options': ['A: Han Dynasty', 'B: Spring and Autumn Period', 'C: Tang Dynasty', 'D: Ming Dynasty'],
        'answer': 'B: Spring and Autumn Period'
    },
    'Q2': {
        'question': "What is the largest planet in the solar system?",
        'options': ['A: Earth', 'B: Jupiter', 'C: Saturn', 'D: Mars'],
        'answer': 'B: Jupiter'
    },
    'Q3': {
        'question': 'Who is the author of "Dream of the Red Chamber"?',
        'options': ["A: Lu Xun", "B: Li Bai", "C: Wu Cheng'en", "D: Cao Xueqin"],
        'answer': 'D: Cao Xueqin'
    },
    'Q4': {
        'question': "What is the tallest mountain in the world?",
        'options': ['A: Mount Everest', 'B: Mount Kilimanjaro', 'C: K2', 'D: Mount Fuji'],
        'answer': 'A: Mount Everest'
    },
    'Q5': {
        'question': "What is the largest organ in the human body?",
        'options': ['A: Heart', 'B: Liver', 'C: Skin', 'D: Brain'],
        'answer': 'C: Skin'
    },
    'Q6': {
        'question': 'Who painted the "Mona Lisa"?',
        'options': ['A: Vincent van Gogh', 'B: Leonardo da Vinci', 'C: Pablo Picasso', 'D: Claude Monet'],
        'answer': 'B: Leonardo da Vinci'
    },
    'Q7': {
        'question': "What is the approximate value of pi?",
        'options': ['A: 2.14', 'B: 3.14', 'C: 4.14', 'D: 1.14'],
        'answer': 'B: 3.14'
    },
    'Q8': {
        'question': "What is the speed of light in a vacuum?",
        'options': ['A: 150,000 km/s', 'B: 299,792 km/s', 'C: 450,000 km/s', 'D: 100,000 km/s'],
        'answer': 'B: 299,792 km/s'
    },
    'Q9': {
        'question': "What is the chemical formula for oxygen?",
        'options': ['A: O₂', 'B: O', 'C: O₃', 'D: CO₂'],
        'answer': 'A: O₂'
    },
    'Q10': {
        'question': "What is Earth's natural satellite?",
        'options': ['A: Mars', 'B: The Sun', 'C: The Moon', 'D: Venus'],
        'answer': 'C: The Moon'
    },
    'Q11': {
        'question': "Why does Doraemon have no ears?",
        'options': ['A: He was born without them', "B: He doesn’t like ears", 'C: He lost them in an accident', 'D: They were eaten by mice'],
        'answer': 'D: They were eaten by mice'
    },
    'Q12': {
        'question': "What does Mr. Krabs from *SpongeBob SquarePants* love the most?",
        'options': ['A: Money', 'B: Food', 'C: Friends', 'D: Adventure'],
        'answer': 'A: Money'
    },
    'Q13': {
        'question': "Which animal is known as the 'doctor of the forest'?",
        'options': ['A: Lion', 'B: Elephant', 'C: Woodpecker', 'D: Monkey'],
        'answer': 'C: Woodpecker'
    },
    'Q14': {
        'question': "What is Olaf's favorite season in *Frozen*?",
        'options': ['A: Winter', 'B: Spring', 'C: Fall', 'D: Summer'],
        'answer': 'D: Summer'
    },
    'Q15': {
        'question': "Which fruit is known as the 'King of Fruits'?",
        'options': ['A: Apple', 'B: Banana', 'C: Durian', 'D: Mango'],
        'answer': 'C: Durian'
    },
    'Q16': {
        'question': "What is Conan Edogawa's real name in *Detective Conan*?",
        'options': ['A: Shinichi Kudo', 'B: Kaito Kid', 'C: Heiji Hattori', 'D: Ran Mori'],
        'answer': 'A: Shinichi Kudo'
    },
    'Q17': {
        'question': "Which animal uses its tail to express emotions?",
        'options': ['A: Cat', 'B: Dog', 'C: Rabbit', 'D: Bird'],
        'answer': 'B: Dog'
    },
    'Q18': {
        'question': "What is Mario's job in *Super Mario*?",
        'options': ['A: Chef', 'B: Plumber', 'C: Teacher', 'D: Pilot'],
        'answer': 'B: Plumber'
    },
    'Q19': {
        'question': "Which animal is known as the 'Ship of the Desert'?",
        'options': ['A: Camel', 'B: Horse', 'C: Elephant', 'D: Zebra'],
        'answer': 'A: Camel'
    },
    'Q20': {
        'question': "What is the name of Harry Potter's first broomstick?",
        'options': ['A: Firebolt', 'B: Nimbus 2000', 'C: Comet 260', 'D: Cleansweep 7'],
        'answer': 'B: Nimbus 2000'
    },
    'Q21': {
        'question': "If all A are B, and all B are C, are all A also C?",
        'options': ['A: Yes', 'B: No', 'C: Sometimes', 'D: Not enough information'],
        'answer': 'A: Yes'
    },
    'Q22': {
        'question': "A clock chimes 6 times in 5 seconds. How long does it take to chime 12 times?",
        'options': ['A: 10 seconds', 'B: 11 seconds', 'C: 12 seconds', 'D: 15 seconds'],
        'answer': 'B: 11 seconds'
    },
    'Q23': {
        'question': "What is the next number in this sequence: 1, 1, 2, 3, 5, 8, 13?",
        'options': ['A: 25', 'B: 23', 'C: 21', 'D: 18'],
        'answer': 'C: 21'
    },
    'Q24': {
        'question': "If 3 people can eat 3 apples in 3 days, how many apples can 9 people eat in 9 days?",
        'options': ['A: 9', 'B: 18', 'C: 27', 'D: 36'],
        'answer': 'C: 27'
    },
    'Q25': {
        'question': "There are 5 apples in a basket. You take away 3. How many apples do you have?",
        'options': ['A: 8', 'B: 11', 'C: 5', 'D: 3'],
        'answer': 'D: 3'
    },
    'Q26': {
        'question': "If today is Monday, what day will it be 100 days from now?",
        'options': ['A: Wednesday', 'B: Thursday', 'C: Friday', 'D: Sunday', ],
        'answer': 'A: Wednesday'
    },
    'Q27': {
        'question': "There are 3 light bulbs in a room and 3 switches outside. You can only enter the room once. How do you determine which switch controls which bulb?",
        'options': ['A: Turn on all switches at once', 'B: Turn on the first switch for a few minutes, then turn it off and turn on the second switch', 'C: Turn on the first switch and leave it on', 'D: Turn on the second switch and leave it on'],
        'answer': 'B: Turn on the first switch for a few minutes, then turn it off and turn on the second switch'
    },
    'Q28': {
        'question': "If 2 cats can catch 2 mice in 2 minutes, how many mice can 6 cats catch in 6 minutes?",
        'options': ['A: 6', 'B: 12', 'C: 18', 'D: 24'],
        'answer': 'A: 6'
    },
    'Q29': {
        'question': "A number, when you remove the first digit, becomes 13. When you remove the last digit, it becomes 40. What is the number?",
        'options': ['A: 43', 'B: 34', 'C: 413', 'D: 431'],
        'answer': 'A: 43'
    },
    'Q30': {
        'question': "If A + B = 10 and A - B = 4, what are A and B?",
        'options': ['A: A = 5, B = 5', 'B: A = 6, B = 4', 'C: A = 8, B = 2', 'D: A = 7, B = 3'],
        'answer': 'D: A = 7, B = 3'
    },
    'Q31': {
        'question': "What can you add to boiling eggs to make the shells easier to peel?",
        'options': ['A: Sugar', 'B: Oil', 'C: Salt', 'D: Baking soda'],
        'answer': 'C: Salt'
    },
    'Q32': {
        'question': "Which fruit is known as the 'King of Vitamin C'?",
        'options': ['A: Apple', 'B: Orange', 'C: Kiwi', 'D: Banana'],
        'answer': 'C: Kiwi'
    },
    'Q33': {
        'question': "How can you store bananas to make them last longer?",
        'options': ['A: Put them in the fridge', 'B: Leave them in a bowl', 'C: Wrap them in plastic', 'D: Hang them up'],
        'answer': 'D: Hang them up'
    },
    'Q34': {
        'question': "Which food is known as the 'King of Breakfast'?",
        'options': ['A: Eggs', 'B: Pancakes', 'C: Cereal', 'D: Toast'],
        'answer': 'A: Eggs'
    },
    'Q35': {
        'question': "How can you tell if a watermelon is ripe?",
        'options': ['A: It has a shiny surface', 'B: It feels soft', 'C: It sounds hollow when tapped', 'D: It is very small'],
        'answer': 'C: It sounds hollow when tapped'
    },
    'Q36': {
        'question': "Which vegetable is known as the 'King of Vegetables'?",
        'options': ['A: Carrot', 'B: Spinach', 'C: Broccoli', 'D: Potato'],
        'answer': 'B: Spinach'
    },
    'Q37': {
        'question': "What is a quick way to defrost frozen meat?",
        'options': ['A: Leave it in the sun', 'B: Boil it', 'C: Microwave it', 'D: Soak it in saltwater'],
        'answer': 'D: Soak it in saltwater'
    },
    'Q38': {
        'question': "Which food can help relieve acid reflux?",
        'options': ['A: Chocolate', 'B: Spicy food', 'C: Soda crackers', 'D: Coffee'],
        'answer': 'C: Soda crackers'
    },
    'Q39': {
        'question': "How can you prevent crying while cutting onions?",
        'options': ['A: Wear goggles', 'B: Cut them underwater', 'C: Chill the onions', 'D: Use a very sharp knife'],
        'answer': 'C: Chill the onions'
    },
    'Q40': {
        'question': "Which fruit is known as 'natural sunscreen'?",
        'options': ['A: Apple', 'B: Grape', 'C: Orange', 'D: Tomato'],
        'answer': 'D: Tomato'
    },
    'Q41': {
        'question': "What is the next number in this sequence: 1, 11, 21, 1211, 111221?",
        'options': ['A: 312211', 'B: 122111', 'C: 111222', 'D: 211112'],
        'answer': 'A: 312211'
    },
    'Q42': {
        'question': "If △ + △ = □, and □ + □ = ○, then what is △ + ○?",
        'options': ['A: □ + △', 'B: △ + □', 'C: ○ + △', 'D: □ + ○'],
        'answer': 'A: □ + △'
    },
    'Q43': {
        'question': "There are three rooms: one with three light bulbs and another with three switches. You can only enter the bulb room once. How do you determine which switch controls which bulb?",
        'options': ['A: Turn on all switches at once', 'B: Turn on the first switch for a few minutes, then turn it off and turn on the second switch', 'C: Turn on the first switch and leave it on', 'D: Turn on the second switch and leave it on'],
        'answer': 'B: Turn on the first switch for a few minutes, then turn it off and turn on the second switch'
    }
}

class Character: 
    # Base character class with HP, AP, DP attributes
    def __init__(self, HP, AP, DP):
        self.max_HP = HP # Maximum_HP, which doesn't change the value between gaming
        self.HP = HP
        self.AP = AP
        self.DP = DP
        self.correct_streak = 0  # Consecutive correct answers
        self.correct = 0 # Total correct answers (for boss battle)
        self.used_skill = False  
        self.min_damage = 5
        self.rebound_damage = 10 # Damage when player answer uncorrectly

    def skill(self, target): # Character-specific skill (to be overridden by subclasses), activated when consecutive 3 correct answers
        pass

    def decrease_hp(self, amount, modifier=1.0, is_rebound=False): # modifier: Damage divider 
        if is_rebound:
            damage = self.rebound_damage
        else:
            damage = max(int(amount * modifier) - self.DP, self.min_damage)
        
        self.HP = max(0, self.HP - damage) # Ensure HP not to be negative value
        print(f"💥 Took {damage} damage! (HP: {self.HP}/{self.max_HP})")
        return self.HP <= 0 # Boolean expression, return True(HP <= 0) or False(HP >= 0)

    def is_defeated(self):
        return self.HP <= 0

    def correct_answer(self): # Check for skill acivation (3 correct answers in a row)
        if self.correct_streak >= 3:
            self.correct_streak = 0
            return True
        return False

class Boss(Character): 
    def __init__(self):
        super().__init__(HP=300, AP=50, DP=0)
        self.name = "Word Tyrant"
        self.min_damage = 20

class IronBastion(Character): # Defensive character with high DP
    def __init__(self):
        super().__init__(HP=120, AP=15, DP=15)
        self.min_damage = 5
        self.rebound_damage = 10
    
    def skill(self, target):
        print("\n🛡️ Using skill: Impenetrable Defense")
        img_8s = Image.open("1742306529969.jpg")
        img_8s.show()
        if target.decrease_hp(self.AP):
            return True
        self.DP += int(self.DP * 0.5)
        print(f"🛡️ Defense increased to {self.DP}!")
        return False # Ensure skill is used once only

class BladeMaster(Character): # Attactive character with high AP
    def __init__(self):
        super().__init__(HP=105, AP=30, DP=5)
        self.min_damage = 5
        self.rebound_damage = 10
    
    def skill(self, target):
        print("\n⚔️ Using skill: Frenzy Blade")
        #skill
        img_7s = Image.open("1742306757118.jpg")
        img_7s.show()
        if target.decrease_hp(self.AP):
            return True
        self.AP += int(self.AP * 0.5)
        print(f"⚔️ Attack increased to {self.AP}!")
        return False # Ensure skill is used once only

class LifeSpring(Character): # Balanced character with healed power
    def __init__(self):
        super().__init__(HP=150, AP=20, DP=10)
        self.min_damage = 5
        self.rebound_damage = 10
    
    def skill(self, target):
        print("\n💚 Using skill: Surge of Life")
        img_9s = Image.open("1742293860216.jpg")
        img_9s.show()
        if target.decrease_hp(self.AP):
            return True
        heal_amount = min(self.max_HP - self.HP, int(self.max_HP * 0.4))
        self.HP += heal_amount
        print(f"💚 Healed for {heal_amount} HP! (HP: {self.HP}/{self.max_HP})")
        return False # Ensure skill is used once only

class Player:
    def __init__(self, name, character):
        self.name = name
        self.character = character
        self.correct_answers = 0 # Track correct answer
        self.total_damage = 0 #Track total danage dealt

class CharacterFactory: # Return specific subclass through player input
    @staticmethod
    def create_character(choice):
        if choice == "2":
            return IronBastion()
        elif choice == "1":
            return BladeMaster()
        elif choice == "3":
            return LifeSpring()
        return None

class CountdownTimer: # Timer for question answering threading
    def __init__(self, duration):
        self.duration = duration
        self.start_time = None
        self.stop_event = Event()

    def start(self):
        self.start_time = time.time()
        Thread(target=self._run, daemon=True).start()

    def _run(self):
        while not self.stop_event.is_set():
            elapsed = time.time() - self.start_time
            remaining = max(self.duration - int(elapsed), 0)
            sys.stdout.write(f"\rTime remaining: {remaining:2d}s ")
            sys.stdout.flush()
            if remaining <= 0:
                self.stop_event.set()
                break
            time.sleep(0.1)
        sys.stdout.write('\r' + ' ' * 30 + '\r')
        sys.stdout.flush()

    def stop(self):
        self.stop_event.set()

class BattleVisualizer: # Visualization of battle results using matplotlib
    @staticmethod
    def show_results(players, boss=None):
        if boss: # Display battle result as bar charts for boss battle
            plt.figure(figsize=(10, 5))

            # Sort players by HP using max_HP
            hp_heap = [(-p.character.HP, p.name) for p in players] # Make the arrangement of player(higher HP) be lower
            heapq.heapify(hp_heap)
            sorted_players = []
            while hp_heap:
                hp, name = heapq.heappop(hp_heap) # Remove the upper player, then know who is winner
                sorted_players.append((name, -hp))
            
            # Plot player HP status
            player_hp = [p[1] for p in sorted_players]
            player_names = [p[0] for p in sorted_players]
            plt.subplot(1, 2, 1)
            plt.bar(player_names, player_hp, color=['green' if hp > 0 else 'red' for hp in player_hp])
            plt.title("Team HP Status")
            plt.ylabel("Remaining HP")
            
            plt.subplot(1, 2, 2)
            boss_hp = boss.HP
            plt.bar(["Boss"], [boss_hp], color='green' if boss_hp > 0 else 'orange')
            plt.title("Boss HP Status")
            plt.ylabel("Remaining HP")
            
            plt.suptitle("Boss Battle Results", y=1.05)
            plt.tight_layout()
            plt.show()
        else: # Player vs player
            hp_values = [p.character.HP for p in players]
            damage_values = [p.total_damage for p in players]
            names = [p.name for p in players]
            
            plt.figure(figsize=(12, 5))
            
            plt.subplot(1, 2, 1)
            hp_bars = plt.bar(names, hp_values, color=['lightgreen' if hp > 0 else 'salmon' for hp in hp_values])
            plt.title("Final HP Comparison")
            plt.ylabel("Remaining HP")
            
            for bar in hp_bars:
                height = bar.get_height()
                plt.text(bar.get_x() + bar.get_width()/2., height,
                        f'{int(height)}',
                        ha='center', va='bottom')
            
            plt.subplot(1, 2, 2)
            damage_bars = plt.bar(names, damage_values, color=['skyblue', 'goldenrod'])
            plt.title("Total Damage Dealt")
            plt.ylabel("Damage Points")
            
            for bar in damage_bars:
                height = bar.get_height()
                plt.text(bar.get_x() + bar.get_width()/2., height,
                        f'{int(height)}',
                        ha='center', va='bottom')
            
            winner = heapq.nlargest(1, [(p.character.HP, p.name) for p in players], key=lambda x: x[0])[0]
            result = "Draw!" if winner[0] <= 0 else f"{winner[1]} wins!"
            plt.suptitle(f"Battle Result: {result}", y=1.05, fontsize=14)
            plt.tight_layout()
            plt.show()

class GameSession: # Game controller handling battle logic
    def __init__(self, players):
        self.players = players
        self.question_pool = list(DATABASE.values())
        random.shuffle(self.question_pool)
        self.max_rounds = 20

    def start_game(self):
        print('**Game Strat!**')
        print("\n=== WORD WARS ===")
        print("\nSelect mode:")
        print("1. Player vs Player")
        print("2. Team vs Boss")
        mode_choice = input("Enter choice (1-2): ").strip()
        
        if mode_choice == "2": 
            return self.start_boss_battle()
        
        # input 1 or other will run following code #PVP
        print('\nWelcome to the arena! You can train your skill here before challenging Word Tyrant through fighting with other player.')
        print("\nGameStart_drawing")
        img_10 = Image.open("1742345678849.jpg")
        img_10.show()
        time.sleep(1)
        print("\nRules:")
        print("- 20 rounds total")
        print("- Correct answer: Deal (AP - DP) damage (min 1)")
        print("- Wrong answer: Damage rebounds to yourself!")
        print("- 3 correct answers in a row unlocks SKILL")
        print("- If no KO after 20 rounds, higher HP wins")
        print("\nStarting battle...\n")
        time.sleep(5)

        for round_num in range(1, self.max_rounds + 1):
            a_index = (round_num - 1) % 2 # odd number
            d_index = 1 - a_index # even number

            attacker = self.players[a_index]
            defender = self.players[d_index]
            
            if attacker.character.is_defeated() or defender.character.is_defeated(): # Check all player HP(<= 0), and return True / False
                break
                
            print(f"\n=== Round {round_num}/{self.max_rounds} ===")
            print(f"Attacker: {attacker.name}")
            self._show_status(attacker, defender)
            
            if self._play_round(attacker, defender):
                break
        
        self._end_game()

    def start_boss_battle(self): # Team vs boss
        boss = Boss()
        print(f"\n=== BOSS BATTLE ===")
        print("\nWord Tyrant: Welcome, challengers, let start our battle which control you and this world's destiny!")
        print("\nGameStart_drawing")
        img_10 = Image.open("1742345678849.jpg")
        img_10.show()
        time.sleep(1)
        print(f"\nFacing {boss.name} (HP: {boss.HP})")
        print("Rules:")
        print("- Team has 10 rounds to defeat Boss")
        print("- All rebound damage will damage 30 HP")
        print("- Word Tyrant deals 50 fixed damage to random alive player every 3 turns")
        print("- Answer 3 correct in a row to unleash Ultimate Skill (Damage 50% Boss HP)")
        print("- Any team member death means failure. ")
        print("However, player (who is still alive) may have the last chance to answer question, this could be the pivotal round that turns the tide in your favor!")
        time.sleep(5)
        
        for round_num in range(1, 11):
            if any(p.character.HP <= 0 for p in self.players): # Check for defeated players
                print("\n☠️ A team member has fallen! Game Over!")
                self._end_boss_game(boss)
                break

            print(f"\n=== Round {round_num}/10 ===")
            
            if round_num % 3 == 0: # Boss attack(50 AP) random (alive) player per 3 turns 
                alive_players = [p for p in self.players if p.character.HP > 0]
                if alive_players:
                    target = random.choice(alive_players) # Boss attack random player
                    print(f"\n☠️ Boss uses Massive Strike on {target.name}!")
                    target.character.HP = max(0, target.character.HP - 50)
                    print(f"{target.name} loses 50 HP! (Remaining {target.character.HP}/{target.character.max_HP})")

                    if target.character.HP <= 0:
                        print(f"\n☠️ {target.name} has fallen!")
                        self._end_boss_game(boss)
                        return
                    
            for player in self.players:
                if player.character.HP <= 0: # Boolean expression
                    continue
                
                if self._play_boss_round(player, boss): # Include checking each HP, if each of them HP <= 0 ->
                    self._end_boss_game(boss)
                    break


    def _show_status(self, attacker, defender): 
        print(f"\n{attacker.name}: {attacker.character.HP}/{attacker.character.max_HP} HP")
        print(f"{defender.name}: {defender.character.HP}/{defender.character.max_HP} HP")
        print(f"{attacker.name}'s streak: {attacker.character.correct_streak}/3")

    def _show_boss_status(self, boss, player):
        print(f"\nBoss HP: {boss.HP}/{boss.max_HP}")
        print(f"{player.name}: {player.character.HP}/{player.character.max_HP} HP")
        print(f"Correct streak: {player.character.correct}/5")

    def _play_round(self, attacker, defender): #Handle player's turn 
        if not self.question_pool:
            self.question_pool = list(DATABASE.values())
            random.shuffle(self.question_pool) 
            
        question = self.question_pool.pop()
        
        print(f"\n{attacker.name}'s question:")
        print(f"Q: {question['question']}")
        for option in question["options"]:
            print(f"  {option}")

        answer = question['answer'][0].upper()
        player_choice = self._get_player_choice(attacker.name)
        
        if player_choice == answer:
            print("\n✅ Correct answer!")
            attacker.character.correct_streak += 1
            attacker.correct_answers += 1
            
            if attacker.character.correct_answer():
                print(f"\n🌟 {attacker.name} activates Skill!")
                defeated = attacker.character.skill(defender.character)
                attacker.character.used_skill = True
                attacker.total_damage += int(attacker.character.AP) # for battle visual bar chart
            else:
                damage = max(attacker.character.AP - defender.character.DP, 5)
                print(f"\n⚔️ {attacker.name} attacks! (AP:{attacker.character.AP} - DP:{defender.character.DP} = {damage} damage)")
                defeated = defender.character.decrease_hp(damage)
                attacker.total_damage += damage # for battle visual bar chart
                
            if defeated:
                print(f"\n💀 {defender.name} has been defeated!")
                return True
            
        elif player_choice is None:
            print("\n⏰ Question skipped!")
            attacker.character.correct_streak = 0
            defeated = attacker.character.decrease_hp(0, is_rebound=True)
            if defeated:
                print(f"\n💀 {attacker.name} defeated themselves!")
                return True
        else:
            print(f"\n❌ Wrong! Correct answer was {answer}")
            print(f"⚡ Damage rebounds! (Fixed rebound damage: {attacker.character.rebound_damage})")
            attacker.character.correct_streak = 0
            defeated = attacker.character.decrease_hp(0, is_rebound=True)
            if defeated:
                print(f"\n💀 {attacker.name} defeated themselves!")
                return True
        
        time.sleep(2)
        return False
    
    def _play_boss_round(self, player, boss):
        if not self.question_pool:
            self.question_pool = list(DATABASE.values())
            random.shuffle(self.question_pool)
            
        question = self.question_pool.pop()
        print(f"\nQ: {question['question']}")
        for option in question["options"]:
            print(f"  {option}")

        answer = question['answer'][0].upper()
        player_choice = self._get_player_choice(player.name)
        
        if player_choice == answer:
            print("\n✅ Correct!")
            player.character.correct += 1
            
            if player.character.correct >= 3 and not player.character.used_skill:
                print("\n🌟 ULTIMATE SKILL ACTIVATED!")
                damage = max(1, int(boss.HP // 2))
                boss.HP -= damage
                print(f"Boss HP reduced to {boss.HP}!")
                player.character.correct = 0
            
            damage = max(player.character.AP - boss.DP, 5)
            boss.decrease_hp(damage)
            player.total_damage += damage
            
        else:
            print(f"\n❌ Wrong! Correct answer was {answer}")
            player.character.correct = 0
            player.character.decrease_hp(boss.AP - 20)
            
        time.sleep(2)
        return boss.is_defeated()

    def _get_player_choice(self, player_name):
        print(f"\n[{player_name}] Press A/B/C/D to answer or ESC to skip:")
        
        answer_queue = Queue()
        def on_press(key):
            try:
                k = key.char.upper()
            except AttributeError:
                k = key.name.upper()
                
            if k in ['A', 'B', 'C', 'D']:
                print(f'\n{player_name} selected: {k}')
                answer_queue.put(k)
                return False
            elif key == keyboard.Key.esc:
                answer_queue.put(None)
                return False

        listener = keyboard.Listener(on_press=on_press)
        listener.start()
        
        timer = CountdownTimer(30)
        timer.start()
        
        try:
            choice = answer_queue.get(timeout=30)
            timer.stop()
            return choice
        except Empty:
            print(f"\n⏰ Time's up for {player_name}!")
            return None
        finally:
            timer.stop()
            listener.stop()

    def _end_game(self):
        #print("\n=== FINAL RESULTS ===")
        alive = [p for p in self.players if not p.character.is_defeated()] # Put alive player who is winner in list
        
        if len(alive) == 1: 
            print(f"🏆 {alive[0].name} WINS by defeating opponent!")
            print("You are the strongest warrior to save our world!")
            img_12 = Image.open("1742357828177.jpg")
            img_12.show()
        else: # No one be defeated after round 20
            winner = max(self.players, key=lambda p: p.character.HP)
            print(f"⏰ 20 rounds completed! Judging by HP:")
            print(f"🏆 {winner.name} WINS with {winner.character.HP} HP remaining!")
            
            for p in self.players:
                status = "💀" if p.character.is_defeated() else "❤️"
                print(f"{status} {p.name}: {p.character.HP}/{p.character.max_HP} HP (Damage: {p.total_damage})")

        BattleVisualizer.show_results(self.players)

    def _end_boss_game(self, boss):
        if boss.is_defeated():
            print("\n🎉 VICTORY! Boss defeated!")
            display_text("A flash of white light—you jolted awake—")
            display_text("Morning sunlight streamed into the dorm room, your notebook still scrawled with battle answers.")
            display_text("From outside came the campus announcement: 'Today's linguistics lecture topic: The Power of Vocabulary'...")
            img_11 = Image.open("1742358213884.jpg")
            img_11.show()
            
            mvp = max(self.players, key=lambda p: p.total_damage)
            print(f"\n🏆 MVP: {mvp.name}")
        else:
            print("\n💀 DEFEAT! Failed to defeat the boss!")
            display_text("Though defeated, a hint of approval flickered across Word Tyrant's lips:")
            display_text("'Not a bad attempt... Bring me a better answer next time.'")
            display_text("The classroom bell suddenly rang—turns out the exam had only just begun.")
            img_13 = Image.open("1742358677280.jpg")
            img_13.show()

            mvp = max(self.players, key=lambda p: p.total_damage)
            print(f"\n🏆 MVP: {mvp.name}")
        
        print(f"\nBoss remaining HP: {boss.HP}")
        for player in self.players:
            status = "ALIVE" if not player.character.is_defeated() else "DEFEATED"
            print(f"{player.name}: {status} (HP: {player.character.HP}) (Damage: {player.total_damage})")

        BattleVisualizer.show_results(self.players, boss)


def select_character(player_num):
    print(f"\nPlayer {player_num}, choose your profession:")
    professions_and_images = [
                ("\nBlade Master (High Attack) \n- 105 HP, 30 AP, 5 DP \n- Frenzy Blade (+50% Damage)", "1742294028241.jpg"),
                ("Iron Bastion (High Defense) \n- 120 HP, 15 AP, 15 DP \n- Impenetrable defence (+50% Defense)", "1742294244709.jpg"),
                ("Life Spring  (High HP) \n- 150 HP, 20 AP, 10 DP \n- Surge of life (+50% HP)", "1742307193264.jpg"),
    ]
    for text, img in professions_and_images:
        display_text(text, delay=0.05)
        if img:
            Image.open(img).show()
            time.sleep(3)

    choice = input("\nEnter choice (1-3): ").strip()
    char = CharacterFactory.create_character(choice)
    if char:
        return char
    print("Invalid choice! Please enter 1, 2, or 3.")
    choice = input("Enter choice (1-3): ").strip()
    char = CharacterFactory.create_character(choice)
    if char:
        return char
    print("Invalid choice! Please enter 1, 2, or 3.")
        

def display_text(text, delay=0.1):
    # Display text character by character
    for char in text:
        print(char, end='', flush=True)
        time.sleep(delay)
    print()

def display_image(image_path):
    try:
        img = Image.open(image_path)
        img.show()
    except FileNotFoundError:
        print(f"Image not found: {image_path}")

def main():
    print("=== WORD WARS ===")

    players = []
    for i in range(1, 3):
        name = input(f"\nEnter Player {i} name: ").strip()
        while not name:
            name = input(f"Player {i} name cannot be empty: ").strip()
        players.append({"name": name})

    player_1 = players[0]["name"]
    player_2 = players[1]["name"]

    texts_and_images = [
            ("\n???: You’ve finally awakened, summoned ones.", '1742307937761.jpg', 'Ves_drawing'),
            (f"\n{player_1}: Who are you? Where are we?\n{player_2}: Why do our clothes and appearance look different?", '1742296990322.jpg', f'{player_1},{player_2}_confusing_drawing'),
            ("\nVes: I am Ves, the last Word Guardian of Lexicon.\n\nThis is Lexicon, a world where language and words are the source of power.\n\nYour clothes and appearance have changed to avoid the eyes of the Word Tyrant.\nIf you don't like, I can change them.\n\nVes: CHANGE CLOTHES", '1742295775011.jpg', 'Magic_drawing'),
            (f"\n{player_1}: better than the original one...\n\nWord Tyrant, who is twisting the power of language, pushing this world toward destruction.", '1742295962084.jpg', 'WordTyrant_drawing'),
            ("\nVes: Many Word Guardians have challenged him, but all have failed...", '1742296270845.jpg', 'WordGuardians_drawing'),
            ("\nVes: To defeat the Word Tyrant, you must fight by answering questions.\nFor every correct answer, you can reduce the opponent's health points (HP).\nWhen one side's HP reaches zero, the battle ends.\nThe Word Tyrant has declared that in three days, he will allow two challengers to face him.\nBut I no longer have the strength to hold out until that day...\nThat why I summoned you to here.\nIf you win, he will restore everything; if you lose, he will rule over all.\nSo, you must prepare now and defeat him!\n\nVes: This will be a difficult battle, but I believe in you. Are you willing to accept this challenge?", '1742297163630.jpg', f'{player_1},{player_2}_agreement_drawing'),
            (f"\n{player_1}: I’m willing!\n{player_2}: I’m willing too!", None, None),
            ("Ves: Excellent! Let us begin this journey!", None, None)
        ]

    while True:
            skip = input('\nDo you want to skip the worldview introduction? (Yes or No)' ).lower()
            if skip in ('yes', 'no'):
                break
            print("Please enter 'Yes' or 'No' ")

    if skip == 'no':
        for text, img, desc in texts_and_images:
            display_text(text)
            if img:
                Image.open(img).show()
                print(f'\n{desc}')
                time.sleep(1)
    else:
        print("Skiping the worldview introduction...")
        time.sleep(1)


    display_text("\nNow! You can choose a profession to power up yourself!\nRemember, you can choose profession once only, choose carefully!\n")

    final_players = []
    for i, player in enumerate(players, 1):
        name = player["name"]
        chr = select_character(i)
        final_players.append(Player(name, chr))
        
    game = GameSession(final_players)
    game.start_game()

if __name__ == "__main__":
    main()