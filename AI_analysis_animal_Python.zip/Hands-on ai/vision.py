import torch
from torchvision.models import resnet18, ResNet18_Weights
from torchvision import transforms
from PIL import Image
from pathlib import Path
import urllib.request

# Step 1: Load model with modern weights API
weights = ResNet18_Weights.DEFAULT
model = resnet18(weights=weights)
model.eval()

# Step 2: Preprocessing pipeline
transform = transforms.Compose([
    transforms.Resize(256),
    transforms.CenterCrop(224),
    transforms.ToTensor(),
    transforms.Normalize(
        mean=[0.485, 0.456, 0.406],
        std=[0.229, 0.224, 0.225]
    )
])

# Step 3: Load ImageNet labels
url = "https://raw.githubusercontent.com/pytorch/hub/master/imagenet_classes.txt"
labels = urllib.request.urlopen(url).read().decode("utf-8").split("\n")

# Step 4: Define prediction function
def predict(image_path):
    img = Image.open(image_path).convert("RGB")
    img_t = transform(img).unsqueeze(0)
    with torch.no_grad():
        outputs = model(img_t)
        _, predicted = outputs.max(1)
    return labels[predicted.item()]

# Step 5: Loop through all images in 'photos' folder
photo_folder = Path("photos")
photo_paths = list(photo_folder.glob("*.jpg")) + list(photo_folder.glob("*.png"))

if not photo_paths:
    print("No images found in 'photos' folder.")
else:
    for path in photo_paths:
        label = predict(path)
        print(f"{path.name} → {label}")