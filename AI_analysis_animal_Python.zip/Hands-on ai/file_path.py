from pathlib import Path

photo_folder = Path("photos")

photo_paths = list(photo_folder.glob("*.jpg")) + list(photo_folder.glob("*.png"))

for path in photo_paths:
    print(f"Found photo: {path.name}")